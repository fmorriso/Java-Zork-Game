
// Examples for working with Arrays in Java
class Main {
  public static void main(String[] args) {

    //Example of replacing a value in a 1-D array of strings
    String[] carsArray = {"Volvo", "BMW", "Ford", "Mazda"};
    carsArray[0] = "Opel"; // Replaces Volvo with Opel
    System.out.println(carsArray[0]+"\n");

    //Example of looping through the above array printing each value
    for (String car : carsArray) {
      System.out.println(car);
    }
    System.out.println();

    // Example of looping through a 2-D array of integers
    int[][] myNumbers = { {1, 2, 3, 4}, {5, 6, 7} };
        for (int i = 0; i < myNumbers.length; ++i) {
          for(int j = 0; j < myNumbers[i].length; ++j) {
            System.out.println(myNumbers[i][j]);
      }
    }
    System.out.println();

    // Example of looping through a 3-D array
    int[][][] myArray = { { { 1, 2 }, { 3, 4 } }, { { 5, 6 }, { 7, 8 } } };
    for (int i = 0; i < 2; i++)
        for (int j = 0; j < 2; j++)
            for (int k = 0; k < 2; k++)
                System.out.println("myArray[" + i
                                   + "]["
                                   + j + "]["
                                   + k + "] = "
                                   + myArray[i][j][k]);
    System.out.println();

    // Condition based on a value in the 3-D array above
    if(myArray[1][1][0] == 7){
    System.out.println(myArray[1][1][0]);      
    }
    System.out.println();

    //Changing a value in the 3-D array above 
    myArray[1][1][0] = 99;
    System.out.println(myArray[1][1][0]);            

  }
}